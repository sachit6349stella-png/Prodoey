package com.prodoey.fps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;

public class ProdoeyFPSClient implements ClientModInitializer {

    private boolean applied = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client != null && client.options != null && !applied) {
                applyTweaks(client);
                applied = true;
            }
        });
    }

    private void applyTweaks(MinecraftClient client) {
        // Safe client-side options that help FPS without breaking the game
        client.options.graphicsMode = GraphicsMode.FAST;
        client.options.cloudRenderMode = net.minecraft.client.option.CloudRenderMode.OFF;
        client.options.entityDistanceScaling = 0.5F;
        client.options.mipmapLevels = 0;
        client.options.enableVsync = false;

        // Reduce particles
        client.options.particles = net.minecraft.client.option.ParticlesMode.MINIMAL;

        // Apply
        client.options.write();
    }
}
