# Prodoey FPS Boost (Fabric)

**Minecraft 1.20.1 – Client-side FPS optimization mod**

## Features
- Sets graphics to FAST
- Disables clouds & VSync
- Reduces entity distance
- Minimal particles
- Zero mixins (very safe)

## How to build JAR
1. Install **Java 17**
2. Open folder in **IntelliJ / VS Code**
3. Run:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. JAR will be in:
   `build/libs/prodoey-fps-boost-1.0.0.jar`

## Install
Put the JAR in:
`.minecraft/mods`
