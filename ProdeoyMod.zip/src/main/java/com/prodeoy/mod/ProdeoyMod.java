package com.prodeoy.mod;

import net.fabricmc.api.ModInitializer;

public class ProdeoyMod implements ModInitializer {

    @Override
    public void onInitialize() {
        System.out.println("Prodeoy Mod Loaded Successfully!");
    }
}
